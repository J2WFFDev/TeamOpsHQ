# prd_elements_workspace.md

(placeholder) If you see this, ask me to regenerate the full content.